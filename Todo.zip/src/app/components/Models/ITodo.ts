export interface ITodo{
    id: number;
    title: string;
    added: Date;
    isFinished: boolean;
}